# Harrison Ndungu - Professional Portfolio Website

This repository contains the full static website source files for **Harrison Ndungu** (ICT Services Specialist & Technical Trainer).

## File Structure
- `index.html`: Main HTML file containing structure and content layout.
- `style.css`: Stylesheet containing branding colors, layout grid, and responsive rules.
- `script.js`: JavaScript for section navigation tabs, slideshow animation, and contact form feedback.
- `images/`: Directory to place your profile and workshop pictures (`profile-placeholder.svg`, `workshop-placeholder.svg`, `1.jpeg`, `2.jpeg`, etc.).

## How to Host on GitHub Pages (Free)
1. Extract all files into a directory.
2. Push all files (`index.html`, `style.css`, `script.js`, `README.md`, and the `images/` directory) to a public repository on GitHub.
3. Go to **Settings > Pages** in your GitHub repository.
4. Under **Source**, choose **Deploy from a branch** and select `main` (root).
5. Click **Save**. Your site will be live within 1 to 3 minutes!
